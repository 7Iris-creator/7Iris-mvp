
document.getElementById('quiz-form').addEventListener('submit', function(event) {
  event.preventDefault();

  const q1 = document.querySelector('input[name="q1"]:checked');
  const q2 = document.querySelector('input[name="q2"]:checked');
  const q3 = document.querySelector('input[name="q3"]:checked');

  if (!q1 || !q2 || !q3) {
    alert("Per favore, rispondi a tutte le domande!");
    return;
  }

  let risultato = "";

  if (q1.value === "fresco" && q2.value === "giallo" && q3.value === "ananas") {
    risultato = "🍍 Smoothie Tropicale – Ananas, cocco e menta";
  } else if (q1.value === "dolce" && q2.value === "rosa" && q3.value === "cocco") {
    risultato = "🥥 Smoothie Rosa Coccoloso – Latte vegetale, fragola e cocco";
  } else if (q1.value === "vitale" && q2.value === "viola" && q3.value === "mirtillo") {
    risultato = "🫐 Smoothie Energia Viola – Mirtillo, banana e semi di chia";
  } else {
    risultato = "✨ Smoothie Iris – Mix speciale su misura per te! Fragole, frutti di bosco e un tocco floreale.";
  }

  document.getElementById('risultato').innerText = risultato;
});
